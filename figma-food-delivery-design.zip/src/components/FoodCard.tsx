import { Star, Plus, Flame, Heart } from 'lucide-react';
import { FoodItem } from '../data';
import { useAppContext } from '../context/AppContext';

interface FoodCardProps {
  item: FoodItem;
  onAdd: (item: FoodItem) => void;
  isFavorite?: boolean;
  onToggleFavorite?: (id: string) => void;
}

export function FoodCard({ item, onAdd, isFavorite, onToggleFavorite }: FoodCardProps) {
  const { t } = useAppContext();

  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300 group relative">
      <div className="relative mb-4 overflow-hidden rounded-2xl h-48">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-3 right-3 flex flex-col gap-2">
            <div className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm px-2 py-1 rounded-lg flex items-center gap-1 shadow-sm">
            <Star size={12} className="text-yellow-400 fill-yellow-400" />
            <span className="text-xs font-bold text-gray-800 dark:text-gray-200">{item.rating}</span>
            </div>
            {onToggleFavorite && (
                <button 
                    onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(item.id);
                    }}
                    className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm p-1.5 rounded-lg flex items-center justify-center shadow-sm hover:scale-110 transition-transform"
                >
                    <Heart size={14} className={isFavorite ? "fill-red-500 text-red-500" : "text-gray-400 dark:text-gray-500"} />
                </button>
            )}
        </div>
        {item.popular && (
          <div className="absolute top-3 left-3 bg-orange-500 text-white px-2 py-1 rounded-lg flex items-center gap-1 shadow-md">
            <Flame size={12} className="fill-white" />
            <span className="text-xs font-bold">{t.foodCard.popular}</span>
          </div>
        )}
      </div>

      <div>
        <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-1 line-clamp-1">{item.name}</h3>
        <p className="text-sm text-gray-400 dark:text-gray-500 mb-4 line-clamp-2 h-10">{item.description}</p>

        <div className="flex items-center justify-between">
          <div>
            <span className="text-xl font-bold text-gray-800 dark:text-white">{item.price} ₽</span>
          </div>
          <button
            onClick={() => onAdd(item)}
            className="w-10 h-10 bg-gray-900 dark:bg-orange-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-gray-200 dark:shadow-none hover:bg-orange-500 dark:hover:bg-orange-600 hover:shadow-orange-200 transition-all duration-300 transform active:scale-90"
          >
            <Plus size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
