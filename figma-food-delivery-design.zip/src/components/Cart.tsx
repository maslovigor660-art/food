import { Minus, Plus, ShoppingBag, CreditCard, QrCode } from 'lucide-react';
import { FoodItem } from '../data';
import { useAppContext } from '../context/AppContext';

interface CartItem extends FoodItem {
  quantity: number;
}

interface CartProps {
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onCheckout: () => void;
}

export function Cart({ items, onUpdateQuantity, onCheckout }: CartProps) {
  const { t, user, paymentMethod, setPaymentMethod } = useAppContext();
  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const delivery = subtotal > 0 ? 250 : 0;
  const total = subtotal + delivery;

  return (
    <div className="w-full h-full bg-white dark:bg-gray-800 p-6 flex flex-col transition-colors border-l border-gray-100 dark:border-gray-700">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-xl font-bold text-gray-800 dark:text-white">{t.cart.title}</h2>
        <span className="text-sm text-orange-500 font-medium cursor-pointer">{t.cart.edit}</span>
      </div>

      {/* Cart Items */}
      <div className="flex-1 overflow-y-auto space-y-6 pr-2">
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-gray-400 dark:text-gray-500">
            <ShoppingBag size={48} className="mb-2 opacity-20" />
            <p>{t.cart.empty}</p>
          </div>
        ) : (
          items.map((item) => (
            <div key={item.id} className="flex gap-4 items-center">
              <img
                src={item.image}
                alt={item.name}
                className="w-16 h-16 rounded-xl object-cover"
              />
              <div className="flex-1">
                <h3 className="text-sm font-semibold text-gray-800 dark:text-white line-clamp-1">{item.name}</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">{item.price} ₽</p>
              </div>
              <div className="flex items-center gap-3 bg-gray-50 dark:bg-gray-700 rounded-lg p-1">
                <button
                  onClick={() => onUpdateQuantity(item.id, -1)}
                  className="p-1 hover:bg-white dark:hover:bg-gray-600 rounded-md shadow-sm transition-all text-gray-600 dark:text-gray-300"
                >
                  <Minus size={14} />
                </button>
                <span className="text-xs font-bold w-4 text-center text-gray-800 dark:text-white">{item.quantity}</span>
                <button
                  onClick={() => onUpdateQuantity(item.id, 1)}
                  className="p-1 hover:bg-white dark:hover:bg-gray-600 rounded-md shadow-sm transition-all text-gray-600 dark:text-gray-300"
                >
                  <Plus size={14} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Summary */}
      {items.length > 0 && (
        <div className="mt-8 pt-8 border-t border-dashed border-gray-200 dark:border-gray-700">
           <div className="space-y-3 mb-6">
            <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
              <span>{t.cart.subtotal}</span>
              <span>{subtotal.toFixed(0)} ₽</span>
            </div>
            <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
              <span>{t.cart.delivery}</span>
              <span>{delivery.toFixed(0)} ₽</span>
            </div>
            <div className="flex justify-between text-lg font-bold text-gray-800 dark:text-white pt-2">
              <span>{t.cart.total}</span>
              <span>{total.toFixed(0)} ₽</span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div className="mb-4">
             <p className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">{t.cart.paymentMethod}</p>
             <div className="flex gap-2">
                <button 
                  onClick={() => setPaymentMethod('card')}
                  className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 border text-sm font-medium transition-all ${
                    paymentMethod === 'card' 
                      ? 'bg-orange-50 border-orange-200 text-orange-600 dark:bg-orange-900/20 dark:border-orange-500/50 dark:text-orange-500' 
                      : 'bg-white border-gray-100 text-gray-500 hover:bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-400'
                  }`}
                >
                   <CreditCard size={16} />
                   {t.cart.card}
                </button>
                <button 
                  onClick={() => setPaymentMethod('qr')}
                  className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 border text-sm font-medium transition-all ${
                    paymentMethod === 'qr' 
                      ? 'bg-orange-50 border-orange-200 text-orange-600 dark:bg-orange-900/20 dark:border-orange-500/50 dark:text-orange-500' 
                      : 'bg-white border-gray-100 text-gray-500 hover:bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-400'
                  }`}
                >
                   <QrCode size={16} />
                   {t.cart.qr}
                </button>
             </div>
          </div>

          <div className="bg-orange-50 dark:bg-orange-900/10 rounded-2xl p-4 mb-6 flex items-center justify-between border border-orange-100 dark:border-orange-500/20">
             <div className="flex items-center gap-3">
               <div className="w-10 h-10 bg-white dark:bg-gray-800 rounded-xl flex items-center justify-center shadow-sm">
                 <CreditCard size={20} className="text-orange-500" />
               </div>
               <div>
                 <p className="text-xs text-gray-500 dark:text-gray-400 uppercase font-semibold">{t.cart.balance}</p>
                 <p className="text-sm font-bold text-gray-800 dark:text-gray-200">{user.balance.toLocaleString()} ₽</p>
               </div>
             </div>
             <button className="text-xs font-bold text-orange-500 bg-white dark:bg-gray-800 px-3 py-1.5 rounded-lg shadow-sm">{t.cart.topUp}</button>
          </div>

          <button 
            onClick={onCheckout}
            className="w-full bg-gray-900 dark:bg-orange-500 text-white py-4 rounded-2xl font-bold shadow-xl shadow-gray-200 dark:shadow-none hover:shadow-gray-300 dark:hover:bg-orange-600 transform active:scale-95 transition-all"
          >
            {t.cart.checkout}
          </button>
        </div>
      )}
    </div>
  );
}
