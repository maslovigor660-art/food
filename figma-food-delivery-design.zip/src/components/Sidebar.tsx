import React from 'react';
import { Home, Heart, Clock, Settings, LogOut, User } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
}

export function Sidebar({ currentView, onNavigate }: SidebarProps) {
  const { t } = useAppContext();

  return (
    <aside className="hidden md:flex flex-col w-24 h-screen bg-white dark:bg-gray-800 border-r border-gray-100 dark:border-gray-700 fixed left-0 top-0 z-20 items-center py-8 transition-colors">
      {/* Logo */}
      <div 
        onClick={() => onNavigate('home')}
        className="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-200 dark:shadow-none mb-12 cursor-pointer hover:scale-105 transition-transform"
      >
        <span className="text-white font-bold text-xl">G</span>
      </div>

      {/* Nav Items */}
      <nav className="flex-1 flex flex-col gap-8 w-full items-center">
        <NavItem 
          icon={<Home size={24} />} 
          active={currentView === 'home'} 
          onClick={() => onNavigate('home')}
          title={t.sidebar.home}
        />
        <NavItem 
          icon={<User size={24} />} 
          active={currentView === 'profile'} 
          onClick={() => onNavigate('profile')}
          title={t.sidebar.profile}
        />
        <NavItem 
          icon={<Heart size={24} />} 
          active={currentView === 'favorites'} 
          onClick={() => onNavigate('favorites')}
          title={t.sidebar.favorites}
        />
        <NavItem 
          icon={<Clock size={24} />} 
          active={currentView === 'history'} 
          onClick={() => onNavigate('history')}
          title={t.sidebar.history}
        />
        <NavItem 
          icon={<Settings size={24} />} 
          active={currentView === 'settings'} 
          onClick={() => onNavigate('settings')}
          title={t.sidebar.settings}
        />
      </nav>

      {/* Bottom */}
      <button className="p-3 text-gray-400 hover:text-orange-500 transition-colors" title={t.settings.logout}>
        <LogOut size={24} />
      </button>
    </aside>
  );
}

function NavItem({ icon, active, onClick, title }: { icon: React.ReactNode; active?: boolean; onClick: () => void; title: string }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`relative p-3 rounded-xl transition-all duration-300 group ${
        active
          ? 'bg-orange-500 text-white shadow-lg shadow-orange-200 dark:shadow-none'
          : 'text-gray-400 hover:bg-orange-50 dark:hover:bg-gray-700 hover:text-orange-500'
      }`}
    >
      {icon}
      {active && (
        <div className="absolute -right-3 top-1/2 -translate-y-1/2 w-1 h-8 bg-orange-500 rounded-l-full hidden" />
      )}
    </button>
  );
}
