import React, { useState } from 'react';
import { Search, SlidersHorizontal, MapPin, ChevronDown, Utensils, Beef, Pizza, Fish, Salad, IceCream, X } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { Cart } from './components/Cart';
import { FoodCard } from './components/FoodCard';
import { Profile } from './components/Profile';
import { Favorites } from './components/Favorites';
import { Settings } from './components/Settings';
import { getCategories, getFoodItems, FoodItem } from './data';
import { useAppContext } from './context/AppContext';

// Map icon strings to components
const iconMap: Record<string, React.ReactNode> = {
  Utensils: <Utensils size={20} />,
  Beef: <Beef size={20} />,
  Pizza: <Pizza size={20} />,
  Fish: <Fish size={20} />,
  Salad: <Salad size={20} />,
  IceCream: <IceCream size={20} />,
};

export function App() {
  const { t, language, user } = useAppContext();
  const [activeCategory, setActiveCategory] = useState('all');
  const [cartItems, setCartItems] = useState<(FoodItem & { quantity: number })[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [currentView, setCurrentView] = useState('home');
  const [favorites, setFavorites] = useState<string[]>([]);

  const categories = getCategories(language);
  const foodItems = getFoodItems(language);

  const filteredItems = foodItems.filter(
    (item) =>
      (activeCategory === 'all' || item.categoryId === activeCategory) &&
      item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const addToCart = (item: FoodItem) => {
    setCartItems((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            return { ...item, quantity: Math.max(0, item.quantity + delta) };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const handleCheckout = () => {
    alert('Ваш заказ успешно оформлен! Спасибо за покупку.');
    setCartItems([]);
    setIsCartOpen(false);
  };

  const toggleFavorite = (id: string) => {
    setFavorites(prev => 
      prev.includes(id) 
        ? prev.filter(itemId => itemId !== id) 
        : [...prev, id]
    );
  };

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900 font-sans text-gray-900 dark:text-gray-100 transition-colors duration-300">
      <Sidebar currentView={currentView} onNavigate={setCurrentView} />

      {/* Main Content */}
      <main className="flex-1 md:ml-24 p-8 overflow-y-auto h-screen scrollbar-hide">
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
          <div>
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-1">
              {t.header.welcome}, <span className="text-orange-500">{user.name.split(' ')[0]}</span> 👋
            </h1>
            <div className="flex items-center gap-2 text-gray-400 dark:text-gray-500 text-sm">
              <MapPin size={16} />
              <span>{user.address}</span>
              <ChevronDown size={14} />
            </div>
          </div>

          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="relative flex-1 md:w-80">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder={t.header.searchPlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white dark:bg-gray-800 pl-12 pr-4 py-3 rounded-2xl border-none shadow-sm dark:shadow-none focus:ring-2 focus:ring-orange-100 dark:focus:ring-orange-900 outline-none placeholder-gray-300 dark:placeholder-gray-600 dark:text-white transition-colors"
              />
            </div>
            <button className="bg-white dark:bg-gray-800 p-3 rounded-2xl shadow-sm dark:shadow-none text-gray-600 dark:text-gray-400 hover:text-orange-500 hover:shadow-md transition-all">
              <SlidersHorizontal size={20} />
            </button>
            <div 
              onClick={() => setCurrentView('profile')}
              className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-2xl overflow-hidden shadow-sm cursor-pointer hover:ring-2 hover:ring-orange-500 transition-all border-2 border-transparent dark:border-gray-600"
            >
                <img src={user.avatar} alt="User" className="w-full h-full object-cover" />
            </div>
          </div>
        </header>

        {currentView === 'home' && (
          <div className="animate-in fade-in duration-500">
            {/* Promo Banner */}
            <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-3xl p-8 mb-10 text-white relative overflow-hidden shadow-2xl shadow-orange-200 dark:shadow-none">
                <div className="relative z-10 max-w-lg">
                    <span className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-lg text-sm font-semibold mb-4 inline-block">{t.promo.freeDelivery}</span>
                    <h2 className="text-4xl font-bold mb-4 leading-tight">{t.promo.discountTitle}</h2>
                    <p className="mb-8 text-orange-100">{t.promo.discountDesc}</p>
                    <button className="bg-white text-orange-600 px-6 py-3 rounded-xl font-bold hover:bg-orange-50 transition-colors shadow-lg">{t.promo.orderNow}</button>
                </div>
                <div className="absolute top-0 right-0 h-full w-1/2 hidden lg:block">
                     <img src="https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80" className="object-cover h-full w-full opacity-30 mix-blend-overlay" />
                     <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-transparent"></div>
                </div>
                 {/* Decorative circles */}
                 <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
                 <div className="absolute top-10 right-1/2 w-20 h-20 bg-yellow-400/20 rounded-full blur-xl"></div>
            </div>

            {/* Categories */}
            <div className="mb-10">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800 dark:text-white">{t.categories.title}</h2>
                <button 
                  onClick={() => setActiveCategory('all')}
                  className="text-orange-500 text-sm font-semibold hover:text-orange-600"
                >
                  {t.categories.all}
                </button>
              </div>
              <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`flex items-center gap-3 px-6 py-4 rounded-2xl min-w-[140px] transition-all duration-300 ${
                      activeCategory === cat.id
                        ? 'bg-gray-900 dark:bg-orange-500 text-white shadow-xl shadow-gray-200 dark:shadow-none scale-105'
                        : 'bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-white/80 dark:hover:bg-gray-700 shadow-sm hover:shadow-md dark:shadow-none'
                    }`}
                  >
                    <div className={`p-2 rounded-full ${activeCategory === cat.id ? 'bg-white/20' : 'bg-gray-100 dark:bg-gray-700'}`}>
                        {iconMap[cat.icon]}
                    </div>
                    <span className="font-semibold">{cat.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Popular Dishes */}
            <div>
              <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-6">{t.foodCard.popular}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
                {filteredItems.map((item) => (
                  <FoodCard 
                    key={item.id} 
                    item={item} 
                    onAdd={addToCart} 
                    isFavorite={favorites.includes(item.id)}
                    onToggleFavorite={toggleFavorite}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {currentView === 'profile' && <Profile />}
        
        {currentView === 'favorites' && (
          <Favorites 
            items={foodItems}
            favorites={favorites}
            onAdd={addToCart}
            onToggleFavorite={toggleFavorite}
            onNavigate={setCurrentView}
          />
        )}

        {currentView === 'settings' && <Settings />}

        {currentView === 'history' && (
            <div className="flex flex-col items-center justify-center h-[60vh] text-gray-400 dark:text-gray-500 animate-in fade-in duration-500">
                <div className="bg-white dark:bg-gray-800 p-8 rounded-full shadow-sm mb-4 transition-colors">
                  <Utensils size={48} className="opacity-20" />
                </div>
                <h2 className="text-xl font-bold text-gray-600 dark:text-gray-300 mb-2">{t.history.title}</h2>
                <p>{t.history.desc}</p>
                <button 
                  onClick={() => setCurrentView('home')}
                  className="mt-6 text-orange-500 font-semibold hover:underline"
                >
                  {t.history.backToMenu}
                </button>
            </div>
        )}
      </main>

      {/* Right Sidebar - Desktop */}
      <aside className="hidden 2xl:block w-96 h-screen sticky top-0 border-l border-gray-100 dark:border-gray-700 shadow-xl shadow-gray-200/50 dark:shadow-none z-10 bg-white dark:bg-gray-800 transition-colors">
        <Cart items={cartItems} onUpdateQuantity={updateQuantity} onCheckout={handleCheckout} />
      </aside>

      {/* Mobile Cart Button (Floating) */}
      <div className="fixed bottom-6 right-6 z-40 2xl:hidden">
          <button 
            onClick={() => setIsCartOpen(true)}
            className="relative bg-gray-900 dark:bg-orange-500 text-white p-4 rounded-full shadow-2xl shadow-gray-400 dark:shadow-none flex items-center justify-center hover:scale-105 transition-transform"
          >
             {cartItems.length > 0 && (
               <div className="absolute -top-2 -right-2 bg-orange-500 dark:bg-white dark:text-orange-500 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center border-2 border-white dark:border-orange-500">
                   {cartItems.reduce((acc, item) => acc + item.quantity, 0)}
               </div>
             )}
             <Utensils size={24} />
          </button>
      </div>

      {/* Mobile Cart Overlay */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 2xl:hidden">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setIsCartOpen(false)}
          />
          
          {/* Drawer */}
          <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white dark:bg-gray-900 shadow-2xl transform transition-transform animate-in slide-in-from-right">
            <button 
              onClick={() => setIsCartOpen(false)}
              className="absolute top-4 right-4 p-2 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 z-10 text-gray-600 dark:text-gray-400"
            >
              <X size={20} />
            </button>
            <Cart items={cartItems} onUpdateQuantity={updateQuantity} onCheckout={handleCheckout} />
          </div>
        </div>
      )}
    </div>
  );
}
