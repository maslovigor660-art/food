import { Bell, Moon, Globe, Shield, ChevronRight, User, HelpCircle, LogOut } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

export function Settings() {
  const { t, theme, toggleTheme, language, setLanguage } = useAppContext();

  return (
    <div className="max-w-4xl mx-auto animate-in fade-in duration-500">
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-8">{t.settings.title}</h2>

      <div className="space-y-6">
        {/* Account Section */}
        <section className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-sm transition-colors">
          <h3 className="text-lg font-bold text-gray-700 dark:text-gray-200 mb-4 flex items-center gap-2">
            <User size={20} className="text-orange-500" />
            {t.settings.account.title}
          </h3>
          <div className="space-y-1">
            <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-colors group">
              <span className="text-gray-600 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white transition-colors">{t.settings.account.personalData}</span>
              <ChevronRight size={18} className="text-gray-400" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-colors group">
              <span className="text-gray-600 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white transition-colors">{t.settings.account.addresses}</span>
              <ChevronRight size={18} className="text-gray-400" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-colors group">
              <span className="text-gray-600 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white transition-colors">{t.settings.account.paymentMethods}</span>
              <ChevronRight size={18} className="text-gray-400" />
            </button>
          </div>
        </section>

        {/* Preferences Section */}
        <section className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-sm transition-colors">
          <h3 className="text-lg font-bold text-gray-700 dark:text-gray-200 mb-4 flex items-center gap-2">
            <Globe size={20} className="text-orange-500" />
            {t.settings.preferences.title}
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg">
                  <Bell size={20} />
                </div>
                <div>
                  <p className="font-semibold text-gray-700 dark:text-gray-200">{t.settings.preferences.notifications}</p>
                  <p className="text-xs text-gray-400 dark:text-gray-500">{t.settings.preferences.notificationsDesc}</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-200 dark:bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-500"></div>
              </label>
            </div>

            <div className="flex items-center justify-between p-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-lg">
                  <Moon size={20} />
                </div>
                <div>
                  <p className="font-semibold text-gray-700 dark:text-gray-200">{t.settings.preferences.darkMode}</p>
                  <p className="text-xs text-gray-400 dark:text-gray-500">{t.settings.preferences.darkModeDesc}</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={theme === 'dark'}
                    onChange={toggleTheme}
                />
                <div className="w-11 h-6 bg-gray-200 dark:bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-500"></div>
              </label>
            </div>

            <div className="flex items-center justify-between p-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg">
                  <Globe size={20} />
                </div>
                <div>
                  <p className="font-semibold text-gray-700 dark:text-gray-200">{t.settings.preferences.language}</p>
                  <p className="text-xs text-gray-400 dark:text-gray-500">{t.settings.preferences.languageDesc}</p>
                </div>
              </div>
              <button 
                onClick={() => setLanguage(language === 'ru' ? 'en' : 'ru')}
                className="text-sm font-semibold text-gray-600 dark:text-gray-300 cursor-pointer hover:text-orange-500 dark:hover:text-orange-400 transition-colors bg-gray-100 dark:bg-gray-700 px-3 py-1.5 rounded-lg"
              >
                {language === 'ru' ? 'Русский' : 'English'}
              </button>
            </div>
          </div>
        </section>

        {/* Support Section */}
        <section className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-sm transition-colors">
          <h3 className="text-lg font-bold text-gray-700 dark:text-gray-200 mb-4 flex items-center gap-2">
            <Shield size={20} className="text-orange-500" />
            {t.settings.support.title}
          </h3>
          <div className="space-y-1">
             <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-colors group">
              <div className="flex items-center gap-3">
                 <HelpCircle size={18} className="text-gray-400" />
                 <span className="text-gray-600 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white transition-colors">{t.settings.support.help}</span>
              </div>
              <ChevronRight size={18} className="text-gray-400" />
            </button>
             <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-colors group">
              <div className="flex items-center gap-3">
                 <Shield size={18} className="text-gray-400" />
                 <span className="text-gray-600 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white transition-colors">{t.settings.support.privacy}</span>
              </div>
              <ChevronRight size={18} className="text-gray-400" />
            </button>
          </div>
        </section>
        
        <button className="w-full bg-red-50 dark:bg-red-900/20 text-red-500 dark:text-red-400 font-bold py-4 rounded-2xl hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors flex items-center justify-center gap-2">
            <LogOut size={20} />
            {t.settings.logout}
        </button>
      </div>
    </div>
  );
}
