import React, { useState } from 'react';
import { User, Mail, Phone, MapPin, Save, Camera } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

export function Profile() {
  const { t, user, updateUser } = useAppContext();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email,
    phone: user.phone,
    address: user.address,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    updateUser(formData);
    setIsEditing(false);
    alert(t.profile.alertUpdated);
  };

  const handleChangePhoto = () => {
      const url = prompt("Введите URL новой фотографии:", user.avatar);
      if (url) {
          updateUser({ avatar: url });
      }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 animate-in fade-in duration-500">
      <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-8">{t.profile.title}</h2>
      
      <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col md:flex-row gap-8 items-start transition-colors">
        {/* Avatar Section */}
        <div className="flex flex-col items-center gap-4 w-full md:w-auto">
          <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-orange-100 dark:border-orange-900 shadow-md relative group">
            <img 
              src={user.avatar} 
              alt="Profile" 
              className="w-full h-full object-cover"
            />
            <div 
                onClick={handleChangePhoto}
                className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
            >
                <Camera className="text-white" />
            </div>
          </div>
          <button 
            onClick={handleChangePhoto}
            className="text-sm text-orange-500 font-semibold hover:text-orange-600 dark:hover:text-orange-400"
          >
            {t.profile.changePhoto}
          </button>
        </div>

        {/* Details Section */}
        <div className="flex-1 w-full space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm text-gray-400 font-medium flex items-center gap-2">
                <User size={16} /> {t.profile.name}
              </label>
              <input
                type="text"
                name="name"
                disabled={!isEditing}
                value={isEditing ? formData.name : user.name}
                onChange={handleChange}
                className={`w-full p-3 rounded-xl border ${
                  isEditing 
                    ? 'border-orange-200 bg-white dark:bg-gray-700 dark:border-orange-500 focus:ring-2 focus:ring-orange-100' 
                    : 'border-gray-100 bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300'
                } outline-none transition-all dark:text-white`}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-400 font-medium flex items-center gap-2">
                <Mail size={16} /> {t.profile.email}
              </label>
              <input
                type="email"
                name="email"
                disabled={!isEditing}
                value={isEditing ? formData.email : user.email}
                onChange={handleChange}
                className={`w-full p-3 rounded-xl border ${
                  isEditing 
                    ? 'border-orange-200 bg-white dark:bg-gray-700 dark:border-orange-500 focus:ring-2 focus:ring-orange-100' 
                    : 'border-gray-100 bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300'
                } outline-none transition-all dark:text-white`}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-400 font-medium flex items-center gap-2">
                <Phone size={16} /> {t.profile.phone}
              </label>
              <input
                type="tel"
                name="phone"
                disabled={!isEditing}
                value={isEditing ? formData.phone : user.phone}
                onChange={handleChange}
                className={`w-full p-3 rounded-xl border ${
                  isEditing 
                    ? 'border-orange-200 bg-white dark:bg-gray-700 dark:border-orange-500 focus:ring-2 focus:ring-orange-100' 
                    : 'border-gray-100 bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300'
                } outline-none transition-all dark:text-white`}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-400 font-medium flex items-center gap-2">
                <MapPin size={16} /> {t.profile.address}
              </label>
              <input
                type="text"
                name="address"
                disabled={!isEditing}
                value={isEditing ? formData.address : user.address}
                onChange={handleChange}
                className={`w-full p-3 rounded-xl border ${
                  isEditing 
                    ? 'border-orange-200 bg-white dark:bg-gray-700 dark:border-orange-500 focus:ring-2 focus:ring-orange-100' 
                    : 'border-gray-100 bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300'
                } outline-none transition-all dark:text-white`}
              />
            </div>
          </div>

          <div className="flex justify-end pt-4">
            {isEditing ? (
              <button 
                onClick={handleSave}
                className="flex items-center gap-2 bg-orange-500 text-white px-6 py-3 rounded-xl font-bold hover:bg-orange-600 transition-colors shadow-lg shadow-orange-200 dark:shadow-none"
              >
                <Save size={18} /> {t.profile.save}
              </button>
            ) : (
              <button 
                onClick={() => {
                    setFormData({
                        name: user.name,
                        email: user.email,
                        phone: user.phone,
                        address: user.address,
                    });
                    setIsEditing(true);
                }}
                className="bg-gray-900 dark:bg-gray-700 text-white px-6 py-3 rounded-xl font-bold hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors shadow-lg dark:shadow-none"
              >
                {t.profile.edit}
              </button>
            )}
          </div>
        </div>
      </div>
      
      {/* Stats Section (Mockup) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 transition-colors">
           <h3 className="text-gray-400 text-sm font-medium mb-2">{t.profile.stats.orders}</h3>
           <p className="text-3xl font-bold text-gray-800 dark:text-white">24</p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 transition-colors">
           <h3 className="text-gray-400 text-sm font-medium mb-2">{t.profile.stats.favorite}</h3>
           <p className="text-xl font-bold text-gray-800 dark:text-white">Бургер</p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 transition-colors">
           <h3 className="text-gray-400 text-sm font-medium mb-2">{t.profile.stats.points}</h3>
           <p className="text-3xl font-bold text-orange-500">{user.balance.toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
}
