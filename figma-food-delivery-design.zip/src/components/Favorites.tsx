import { FoodItem } from '../data';
import { FoodCard } from './FoodCard';
import { Heart } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

interface FavoritesProps {
  items: FoodItem[];
  favorites: string[];
  onAdd: (item: FoodItem) => void;
  onToggleFavorite: (id: string) => void;
  onNavigate: (view: string) => void;
}

export function Favorites({ items, favorites, onAdd, onToggleFavorite, onNavigate }: FavoritesProps) {
  const { t } = useAppContext();
  const favoriteItems = items.filter(item => favorites.includes(item.id));

  if (favoriteItems.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center">
        <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-full mb-6 transition-colors">
          <Heart size={48} className="text-gray-300 dark:text-gray-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">{t.favorites.emptyTitle}</h2>
        <p className="text-gray-500 dark:text-gray-400 mb-8 max-w-md">
          {t.favorites.emptyDesc}
        </p>
        <button
          onClick={() => onNavigate('home')}
          className="bg-orange-500 text-white px-8 py-3 rounded-xl font-bold hover:bg-orange-600 transition-colors shadow-lg shadow-orange-200 dark:shadow-none"
        >
          {t.favorites.goToMenu}
        </button>
      </div>
    );
  }

  return (
    <div className="animate-in fade-in duration-500">
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6 flex items-center gap-2">
        <Heart className="text-red-500 fill-red-500" />
        {t.favorites.title} ({favoriteItems.length})
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
        {favoriteItems.map((item) => (
          <FoodCard 
            key={item.id} 
            item={item} 
            onAdd={onAdd}
            isFavorite={true}
            onToggleFavorite={onToggleFavorite}
          />
        ))}
      </div>
    </div>
  );
}
