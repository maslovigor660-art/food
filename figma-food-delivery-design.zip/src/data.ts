import { Language } from './translations';

export interface Category {
  id: string;
  name: string;
  nameEn: string;
  icon: string;
}

export interface FoodItem {
  id: string;
  name: string;
  nameEn: string;
  description: string;
  descriptionEn: string;
  price: number;
  rating: number;
  calories: number;
  image: string;
  categoryId: string;
  popular?: boolean;
}

export const categoriesData: Category[] = [
  { id: 'all', name: 'Все', nameEn: 'All', icon: 'Utensils' },
  { id: 'burger', name: 'Бургеры', nameEn: 'Burgers', icon: 'Beef' },
  { id: 'pizza', name: 'Пицца', nameEn: 'Pizza', icon: 'Pizza' },
  { id: 'sushi', name: 'Суши', nameEn: 'Sushi', icon: 'Fish' },
  { id: 'salad', name: 'Салаты', nameEn: 'Salads', icon: 'Salad' },
  { id: 'dessert', name: 'Десерты', nameEn: 'Desserts', icon: 'IceCream' },
];

export const foodItemsData: FoodItem[] = [
  {
    id: '1',
    name: 'Острый Говяжий Бургер',
    nameEn: 'Spicy Beef Burger',
    description: 'Двойная говяжья котлета с острым халапеньо и расплавленным чеддером.',
    descriptionEn: 'Double beef patty with spicy jalapeños and melted cheddar.',
    price: 890,
    rating: 4.8,
    calories: 540,
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80',
    categoryId: 'burger',
    popular: true,
  },
  {
    id: '2',
    name: 'Маргарита Классическая',
    nameEn: 'Classic Margherita',
    description: 'Свежая моцарелла, базилик и наш фирменный томатный соус.',
    descriptionEn: 'Fresh mozzarella, basil, and our signature tomato sauce.',
    price: 750,
    rating: 4.6,
    calories: 800,
    image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=800&q=80',
    categoryId: 'pizza',
    popular: true,
  },
  {
    id: '3',
    name: 'Сет с Лососем',
    nameEn: 'Salmon Set',
    description: 'Свежий атлантический лосось на приправленном рисе (6 шт).',
    descriptionEn: 'Fresh Atlantic salmon on seasoned rice (6 pcs).',
    price: 1200,
    rating: 4.9,
    calories: 320,
    image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=800&q=80',
    categoryId: 'sushi',
  },
  {
    id: '4',
    name: 'Салат Цезарь',
    nameEn: 'Caesar Salad',
    description: 'Хрустящий салат ромэн, пармезан, сухарики и соус цезарь.',
    descriptionEn: 'Crispy romaine lettuce, parmesan, croutons, and Caesar dressing.',
    price: 550,
    rating: 4.5,
    calories: 210,
    image: 'https://images.unsplash.com/photo-1550304943-4f24f54ddde9?auto=format&fit=crop&w=800&q=80',
    categoryId: 'salad',
  },
  {
    id: '5',
    name: 'Пицца с Трюфелем и Грибами',
    nameEn: 'Truffle & Mushroom Pizza',
    description: 'Белая основа с лесными грибами и трюфельным маслом.',
    descriptionEn: 'White base with wild mushrooms and truffle oil.',
    price: 950,
    rating: 4.7,
    calories: 850,
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80',
    categoryId: 'pizza',
  },
  {
    id: '6',
    name: 'Двойной Чизбургер',
    nameEn: 'Double Cheeseburger',
    description: 'Две котлеты, двойной сыр, салат, помидор и домашний соус.',
    descriptionEn: 'Two patties, double cheese, lettuce, tomato, and house sauce.',
    price: 920,
    rating: 4.6,
    calories: 720,
    image: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?auto=format&fit=crop&w=800&q=80',
    categoryId: 'burger',
  },
  {
    id: '7',
    name: 'Ягодный Чизкейк',
    nameEn: 'Berry Cheesecake',
    description: 'Сливочный чизкейк со свежими лесными ягодами.',
    descriptionEn: 'Creamy cheesecake with fresh forest berries.',
    price: 450,
    rating: 4.8,
    calories: 450,
    image: 'https://images.unsplash.com/photo-1524351199678-c419ee79d0b3?auto=format&fit=crop&w=800&q=80',
    categoryId: 'dessert',
    popular: true,
  },
  {
    id: '8',
    name: 'Ролл Дракон',
    nameEn: 'Dragon Roll',
    description: 'Угорь и огурец внутри, сверху авокадо.',
    descriptionEn: 'Eel and cucumber inside, topped with avocado.',
    price: 1100,
    rating: 4.9,
    calories: 380,
    image: 'https://images.unsplash.com/photo-1553621042-f6e147245754?auto=format&fit=crop&w=800&q=80',
    categoryId: 'sushi',
  },
  {
    id: '9',
    name: 'Греческий Салат',
    nameEn: 'Greek Salad',
    description: 'Свежие овощи, сыр фета, оливки и оливковое масло.',
    descriptionEn: 'Fresh vegetables, feta cheese, olives, and olive oil.',
    price: 480,
    rating: 4.7,
    calories: 180,
    image: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&w=800&q=80',
    categoryId: 'salad',
  },
  {
    id: '10',
    name: 'Пепперони',
    nameEn: 'Pepperoni',
    description: 'Классическая пицца с колбасками пепперони и сыром моцарелла.',
    descriptionEn: 'Classic pizza with pepperoni slices and mozzarella cheese.',
    price: 780,
    rating: 4.8,
    calories: 750,
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=800&q=80',
    categoryId: 'pizza',
    popular: true,
  },
  {
    id: '11',
    name: 'Чикен Бургер',
    nameEn: 'Chicken Burger',
    description: 'Сочная куриная котлета в хрустящей панировке.',
    descriptionEn: 'Juicy chicken patty in crispy breading.',
    price: 650,
    rating: 4.5,
    calories: 600,
    image: 'https://images.unsplash.com/photo-1615297928064-24977384d0f9?auto=format&fit=crop&w=800&q=80',
    categoryId: 'burger',
  },
  {
    id: '12',
    name: 'Шоколадный Брауни',
    nameEn: 'Chocolate Brownie',
    description: 'Теплый шоколадный кекс с шариком ванильного мороженого.',
    descriptionEn: 'Warm chocolate cake with a scoop of vanilla ice cream.',
    price: 390,
    rating: 4.9,
    calories: 520,
    image: 'https://images.unsplash.com/photo-1564355808539-22fda35bed7e?auto=format&fit=crop&w=800&q=80',
    categoryId: 'dessert',
  },
  {
    id: '13',
    name: 'Филадельфия',
    nameEn: 'Philadelphia',
    description: 'Лосось, сливочный сыр и огурец.',
    descriptionEn: 'Salmon, cream cheese, and cucumber.',
    price: 990,
    rating: 4.8,
    calories: 350,
    image: 'https://images.unsplash.com/photo-1617196034496-64ac796002bb?auto=format&fit=crop&w=800&q=80',
    categoryId: 'sushi',
    popular: true,
  },
  {
    id: '14',
    name: 'Поке с Тунцом',
    nameEn: 'Tuna Poke',
    description: 'Свежий тунец, авокадо, рис и овощи.',
    descriptionEn: 'Fresh tuna, avocado, rice, and vegetables.',
    price: 850,
    rating: 4.7,
    calories: 420,
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
    categoryId: 'salad',
  },
  {
    id: '15',
    name: 'Тирамису',
    nameEn: 'Tiramisu',
    description: 'Итальянский десерт с кофейным вкусом и кремом маскарпоне.',
    descriptionEn: 'Italian coffee-flavored dessert with mascarpone cream.',
    price: 420,
    rating: 4.6,
    calories: 380,
    image: 'https://images.unsplash.com/photo-1571875257727-256c39da42af?auto=format&fit=crop&w=800&q=80',
    categoryId: 'dessert',
  },
  {
    id: '16',
    name: 'Гавайская Пицца',
    nameEn: 'Hawaiian Pizza',
    description: 'Ветчина, ананасы, сыр моцарелла и томатный соус.',
    descriptionEn: 'Ham, pineapples, mozzarella cheese, and tomato sauce.',
    price: 760,
    rating: 4.4,
    calories: 720,
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80',
    categoryId: 'pizza',
  },
  {
    id: '17',
    name: 'Веган Бургер',
    nameEn: 'Vegan Burger',
    description: 'Растительная котлета, свежие овощи и веганский соус.',
    descriptionEn: 'Plant-based patty, fresh vegetables, and vegan sauce.',
    price: 820,
    rating: 4.5,
    calories: 480,
    image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80',
    categoryId: 'burger',
  },
  {
    id: '18',
    name: 'Сет Калифорния',
    nameEn: 'California Set',
    description: 'Краб, авокадо, огурец и икра масаго (8 шт).',
    descriptionEn: 'Crab, avocado, cucumber, and masago roe (8 pcs).',
    price: 890,
    rating: 4.7,
    calories: 340,
    image: 'https://images.unsplash.com/photo-1611143669185-af224c5e3252?auto=format&fit=crop&w=800&q=80',
    categoryId: 'sushi',
  },
];

export const getCategories = (lang: Language) => {
  return categoriesData.map(c => ({
    ...c,
    name: lang === 'ru' ? c.name : c.nameEn
  }));
};

export const getFoodItems = (lang: Language) => {
  return foodItemsData.map(i => ({
    ...i,
    name: lang === 'ru' ? i.name : i.nameEn,
    description: lang === 'ru' ? i.description : i.descriptionEn
  }));
};
