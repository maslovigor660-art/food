import React, { createContext, useContext, useState, useEffect } from 'react';
import { translations, Language } from '../translations';

interface User {
  name: string;
  email: string;
  phone: string;
  address: string;
  avatar: string;
  balance: number;
}

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  user: User;
  updateUser: (user: Partial<User>) => void;
  paymentMethod: 'card' | 'qr';
  setPaymentMethod: (method: 'card' | 'qr') => void;
  t: typeof translations['ru'];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const defaultUser: User = {
  name: 'Алекс Смирнов',
  email: 'alex.smirnov@example.com',
  phone: '+7 (999) 123-45-67',
  address: 'ул. Ленина 123, кв. 45, Москва',
  avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&w=300&q=80',
  balance: 12450,
};

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('ru');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [user, setUser] = useState<User>(defaultUser);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'qr'>('card');

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const updateUser = (updates: Partial<User>) => {
    setUser((prev) => ({ ...prev, ...updates }));
  };

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const t = translations[language];

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        theme,
        toggleTheme,
        user,
        updateUser,
        paymentMethod,
        setPaymentMethod,
        t,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}
